<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['mongo_server'] = 'localhost';
$config['mongo_dbname'] = 'onlinelibrary'; // Databse Name
$config['mongo_auth']   = FALSE;
$config['mongo_username'] = '';
$config['mongo_password'] = '';

?>