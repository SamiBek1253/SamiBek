<?php

/**
 * 
 */
class bAuthorController extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("bAuthorModel");
	}

	function atoInc(){
         $query = $this->mongoci->db->book_author->findOne();
         return 1;
	}
	
	function index(){
         $data['title']  = "Book Author Registration";
         $data['data']   = $this->bAuthorModel->getData();
		 $this->load->view("view/bookAuthorRegistration",$data);
	}

	function insert(){

		$name = $this->input->post("name");
		$this->form_validation->set_rules("name","Author","required");
		if($this->form_validation->run() ==FALSE){
          $this->index();
		}else{

			$data =array(
             'name'=>$name,
              'id'=>$this->atoInc()
			);

			if($this->bAuthorModel->insert($data)){
                $this->session->set_flashdata("success","Operation Was Successfull");
                $this->index();
			}
		}

	}

	function edit($id){
		$data['title'] = "Edit Book Author";
        $data['data'] = $this->bAuthorModel->edit($id);
       
        $this->load->view('view/editbAuthor',$data);
	}
	function updateCol($id){
		$name = $this->input->post('name');
		$data = array(
			'name' =>$name);

		if($this->bAuthorModel->updateCol($id,$data)){
          $this->session->set_flashdata("success","Operation  Successfull");

          redirect("bAuthorController/index");
		}else{
			$this->session->set_flashdata("success","Operation Was not Successfull");
           // $this->index();
		}
	}

	function delete($id){
       if($this->bAuthorModel->delete($id)){
            $this->session->set_flashdata("success","Operation Was Successfull");
            $this->index();
       }else{
       	   $this->session->set_flashdata("success","Operation Was not Successfull");
            $this->index();
       }
	}
}

 ?>