<?php

/**
 * 
 */
class bLanguageController extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("bLanguageModel");
	}

	function atoInc(){
         $query = $this->mongoci->db->book_category->findOne();
         return 1;
	}
	
	function index(){
         $data['title']  = "Book Language Registration";
         $data['data']   = $this->bLanguageModel->getData();
		 $this->load->view("view/bookLanguageRegistration",$data);
	}

	function insert(){

		$name = $this->input->post("name");
		$this->form_validation->set_rules("name","Language","required");
		if($this->form_validation->run() ==FALSE){
          $this->index();
		}else{

			$data =array(
             'name'=>$name,
              'id'=>$this->atoInc()
			);

			if($this->bLanguageModel->insert($data)){
                $this->session->set_flashdata("success","Operation Was Successfull");
                $this->index();
			}
		}

	}

	function edit($id){
		$data['title'] = "Edit Book Language";
        $data['data'] = $this->bLanguageModel->edit($id);
       
        $this->load->view('view/editbLanguage',$data);
	}
	function updateCol($id){
		$name = $this->input->post('name');
		$data = array(
			'name' =>$name);

		if($this->bLanguageModel->updateCol($id,$data)){
          $this->session->set_flashdata("success","Operation  Successfull");

          redirect("bLanguageController/index");
		}else{
			$this->session->set_flashdata("success","Operation Was not Successfull");
           // $this->index();
		}
	}

	function delete($id){
       if($this->bLanguageModel->delete($id)){
            $this->session->set_flashdata("success","Operation Was Successfull");
            $this->index();
       }else{
       	   $this->session->set_flashdata("success","Operation Was not Successfull");
            $this->index();
       }
	}
}

 ?>