<?php

/**
 * 
 */
class bPublisherController extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("bPublisherModel");
	}

	function atoInc(){
         $query = $this->mongoci->db->book_publisher->findOne();
         return 1;
	}
	
	function index(){
         $data['title']  = "Book Publisher Registration";
         $data['data']   = $this->bPublisherModel->getData();
		 $this->load->view("view/bookPublisherRegistration",$data);
	}

	function insert(){

		$name = $this->input->post("name");
		$this->form_validation->set_rules("name","Publisher","required");
		if($this->form_validation->run() ==FALSE){
          $this->index();
		}else{

			$data =array(
             'name'=>$name,
              'id'=>$this->atoInc()
			);

			if($this->bPublisherModel->insert($data)){
                $this->session->set_flashdata("success","Operation Was Successfull");
                $this->index();
			}
		}

	}

	function edit($id){
		$data['title'] = "Edit Book Publisher";
        $data['data'] = $this->bPublisherModel->edit($id);
       
        $this->load->view('view/editbPublisher',$data);
	}
	function updateCol($id){
		$name = $this->input->post('name');
		$data = array(
			'name' =>$name);

		if($this->bPublisherModel->updateCol($id,$data)){
          $this->session->set_flashdata("success","Operation  Successfull");

          redirect("bPublisherController/index");
		}else{
			$this->session->set_flashdata("success","Operation Was not Successfull");
           // $this->index();
		}
	}

	function delete($id){
       if($this->bPublisherModel->delete($id)){
            $this->session->set_flashdata("success","Operation Was Successfull");
            $this->index();
       }else{
       	   $this->session->set_flashdata("success","Operation Was not Successfull");
            $this->index();
       }
	}
}

 ?>