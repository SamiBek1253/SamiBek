<?php

/**
 * 
 */
class bookController extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("bookModel");
	}

	function atoInc(){
         $query = $this->mongoci->db->book->findOne();
         return 1;
	}
	
	function index(){
         $data['title']       = "Book  Registration";
         $data['data']        = $this->bookModel->getData();
         
		 $this->load->view("view/bookRegistration",$data);
	}

	function insert(){

		$name        = $this->input->post("name");
		$category_id = $this->input->post("category_id");
		$publisher_id= $this->input->post("publisher_id");
		$language_id = $this->input->post("language_id");
		$author_id   = $this->input->post("author_id");
		$pages        = $this->input->post("pages");

		$this->form_validation->set_rules("name","Name","required");
		$this->form_validation->set_rules("category_id","Category ","required");
		$this->form_validation->set_rules("publisher_id","publisher","required");
		$this->form_validation->set_rules("language_id","Language","required");
		$this->form_validation->set_rules("author_id","Author","required");
		if($this->form_validation->run() ==FALSE){

          $this->index();

		}else{
			

			$data =array(
             'name'=>$name,
             'category_id'=>$category_id,
             'language_id'=>$language_id,
             'author_id'=>$author_id,
             'publisher_id'=>$publisher_id,
             'pages'=>$pages,
             'deleted'=>0,
              'id'=>$this->atoInc()
			);

			if($this->bookModel->insert($data)){
                $this->session->set_flashdata("success","Operation Was Successfull");
                $this->index();
			}
		}

	}

	function edit($id){
		$data['title'] = "Edit Book ";
        $data['data'] = $this->bookModel->edit($id);
        
        $this->load->view('view/edit_book',$data);
	}
	function updateCol($id){
		$name        = $this->input->post("name");
		$category_id = $this->input->post("category_id");
		$publisher_id= $this->input->post("publisher_id");
		$language_id = $this->input->post("language_id");
		$author_id   = $this->input->post("author_id");
		$pages       = $this->input->post("pages");

		$data =array(
             'name'=>$name,
             'category_id' =>$category_id,
             'language_id' =>$language_id,
             'author_id'   =>$author_id,
             'publisher_id'=>$publisher_id,
             'pages'       =>$pages,
             'deleted'     =>0
			);

		if($this->bookModel->updateCol($id,$data)){
          $this->session->set_flashdata("success","Operation  Successfull");

          redirect("bookController/index");
		}else{
			$this->session->set_flashdata("success","Operation Was not Successfull");
           // $this->index();
			redirect("bookController/index");
		}
	}

	function delete($id){
       if($this->bookModel->delete($id)){
            $this->session->set_flashdata("success","Operation Was Successfull");
            $this->index();
       }else{
       	   $this->session->set_flashdata("success","Operation Was not Successfull");
            $this->index();
       }
	}
}

 ?>