<?php

/**
 * 
 */
class uCategoryController extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("uCategoryModel");
	}

	function atoInc(){
         $query = $this->mongoci->db->book_category->findOne();
         return 1;
	}
	
	function index(){
         $data['title']  = "User Category Registration";
         $data['data']   = $this->uCategoryModel->getData();
		 $this->load->view("view/userCategoryRegistration",$data);
	}

	function insert(){

		$name = $this->input->post("name");
		$this->form_validation->set_rules("name","Category","required");
		if($this->form_validation->run() ==FALSE){
          $this->index();
		}else{

			$data =array(
             'name'=>$name,
              'id'=>$this->atoInc()
			);

			if($this->uCategoryModel->insert($data)){
                $this->session->set_flashdata("success","Operation Was Successfull");
                $this->index();
			}
		}

	}

	function edit($id){
		$data['title'] = "Edit User Category";
        $data['data'] = $this->uCategoryModel->edit($id);
        
        $this->load->view('view/edituCategory',$data);
	}
	function updateCol($id){
		$name = $this->input->post('name');
		$data = array(
			'name' =>$name);

		if($this->uCategoryModel->updateCol($id,$data)){
          $this->session->set_flashdata("success","Operation  Successfull");

          redirect("uCategoryController/index");
		}else{
			$this->session->set_flashdata("success","Operation Was not Successfull");
           // $this->index();
		}
	}

	function delete($id){
       if($this->uCategoryModel->delete($id)){
            $this->session->set_flashdata("success","Operation Was Successfull");
            $this->index();
       }else{
       	   $this->session->set_flashdata("success","Operation Was not Successfull");
            $this->index();
       }
	}
}

 ?>