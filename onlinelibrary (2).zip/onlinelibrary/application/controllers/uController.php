<?php

/**
 * 
 */
class uController extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("uModel");
	}

	function atoInc(){
         $query = $this->mongoci->db->users->findOne();
         return 1;
	}
	
	function index(){
         $data['title']  = "User  Registration";
         $data['data']   = $this->uModel->getData();
         $data['category']   = $this->uModel->getCategory();
		 $this->load->view("view/userRegistration",$data);
	}

	function insert(){

		$name        = $this->input->post("name");
		$lname       = $this->input->post("lname");
		$fname       = $this->input->post("fname");
		$username    = $this->input->post("username");
		$password    = $this->input->post("password");
		$email       = $this->input->post("email");
		$category_id = $this->input->post("category_id");

		$this->form_validation->set_rules("name","Name","required");
		$this->form_validation->set_rules("lname","Last Name","required");
		$this->form_validation->set_rules("fname","Father Name","required");
		$this->form_validation->set_rules("email","Email","required|valid_email");
		$this->form_validation->set_rules("password","Password","required|min_length[5]");
		if($this->form_validation->run() ==FALSE){
          $this->index();
		}else{

			$data =array(
             'name'=>$name,
             'lname'=>$lname,
             'fname'=>$fname,
             'username'=>$username,
             'email'=>$email,
             'password'=>$password,
             'deleted'=>0,
              'id'=>$this->atoInc()
			);

			if($this->uModel->insert($data)){
                $this->session->set_flashdata("success","Operation Was Successfull");
                $this->index();
			}
		}

	}

	function edit($id){
		$data['title'] = "Edit User Category";
        $data['data'] = $this->uModel->edit($id);
        
        $this->load->view('view/edit_user',$data);
	}
	function updateCol($id){
		$name        = $this->input->post("name");
		$lname       = $this->input->post("lname");
		$fname       = $this->input->post("fname");
		$username    = $this->input->post("username");
		$password    = $this->input->post("password");
		$email       = $this->input->post("email");
		$category_id = $this->input->post("category_id");

		$data =array(
             'name'=>$name,
             'lname'=>$lname,
             'fname'=>$fname,
             'username'=>$username,
             'email'=>$email,
             'password'=>$password,
             'deleted'=>0,
              'id'=>$this->atoInc()
			);

		if($this->uModel->updateCol($id,$data)){
          $this->session->set_flashdata("success","Operation  Successfull");

          redirect("uController/index");
		}else{
			$this->session->set_flashdata("success","Operation Was not Successfull");
           // $this->index();
		}
	}

	function delete($id){
       if($this->uModel->delete($id)){
            $this->session->set_flashdata("success","Operation Was Successfull");
            $this->index();
       }else{
       	   $this->session->set_flashdata("success","Operation Was not Successfull");
            $this->index();
       }
	}


	function logout(){

		 $this->index();
	}
}

 ?>