<?php 

/**
 * 
 */
class bCategoryModel extends CI_Model
{

	function getData(){

		return $this->mongoci->db->book_category->find();
	}

	function insert($data){
     
     return $this->mongoci->db->book_category->insert($data);

	}

	function edit($id){
       $id = intval($id);
       return $this->mongoci->db->book_category->findOne(array("id" =>$id));
  }  

   function updateCol($id,$data){
        $id = intval($id);
        return  $this->mongoci->db->book_category->update(array("id"=>$id),array('$set'=>$data));
   } 

   function delete($id){
       $id = intval($id);
        return $this->mongoci->db->book_category->remove(array('id'=>$id),array("justOne"=>1));
   }
}

?>