<?php 

/**
 * 
 */
class bLanguageModel extends CI_Model
{

  function getData(){

    return $this->mongoci->db->language->find();
  }

  function insert($data){
     
     return $this->mongoci->db->language->insert($data);

  }

  function edit($id){
       $id = intval($id);
       return $this->mongoci->db->language->findOne(array("id" =>$id));
  }  

   function updateCol($id,$data){
        $id = intval($id);
        return  $this->mongoci->db->language->update(array("id"=>$id),array('$set'=>$data));
   } 

   function delete($id){
       $id = intval($id);
        return $this->mongoci->db->language->remove(array('id'=>$id),array("justOne"=>1));
   }
}

?>