<?php 

/**
 * 
 */
class bookModel extends CI_Model
{

  function getData(){

    return $this->mongoci->db->book->find();
    
  }

  function getbCategory(){


    return $this->mongoci->db->book_category->find();
  }

  function getbPublisher(){

    return $this->mongoci->db->book_publisher->find();
  }

  function getbAuthor(){

    return $this->mongoci->db->book_author->find();
  }

  function getbLanguage(){
    return $this->mongoci->db->language->find();
  }


  function getbCategoryOne($id){

     $id = intval($id);

    return $this->mongoci->db->book_category->findOne(array("id"=>$id));
  }

  function getbPublisherOne($id){

     $id = intval($id);

    return $this->mongoci->db->book_publisher->findOne(array("id"=>$id));
  }

  function getbAuthorOne($id){
    $id = intval($id);

    return $this->mongoci->db->book_author->findOne(array("id"=>$id));
  }

  function getbLanguageOne($id){
   $id = intval($id);
    return $this->mongoci->db->language->findOne(array("id"=>$id));
  }

  function insert($data){
     
     return $this->mongoci->db->book->insert($data);

  }

  function edit($id){
       $id = intval($id);
       return $this->mongoci->db->book->findOne(array("id" =>$id));
  }  

   function updateCol($id,$data){
        $id = intval($id);
        return  $this->mongoci->db->book->update(array("id"=>$id),array('$set'=>$data));
   } 

   function delete($id){
       $id = intval($id);
        return $this->mongoci->db->book->remove(array('id'=>$id),array("justOne"=>1));
   }
}

?>