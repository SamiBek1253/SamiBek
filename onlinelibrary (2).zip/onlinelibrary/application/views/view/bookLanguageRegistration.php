<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
include("head.php"); ?>
<body>
     
   <?php include("sidebar.php"); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-lg-12">
                     <h2><?php echo $title;?></h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="alert alert-info">
                             <strong><?php echo $title;?> </strong>
                        </div>
					            	<?php 
                          if($this->session->flashdata('success')): ?>
                            <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
                        <?php endif; ?>
                    </div>
                    </div>
                  <!-- /. ROW  --> 
				 
                    <div class="row">
					   <?php echo form_open("bLanguageController/insert"); ?>
						  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
							   <div class="form-group">
								 <label><?php echo form_label("Language Name","name"); ?></label>
                  <?php echo form_input(array('name'=>'name','id'=>'name','Placeholder'=>"name",'autocomplete'=>'off','value'=>set_value('name'),'class'=>'form-control')); ?>
                  <?php echo form_error('name','<div class="text-danger" >','</div>'); ?>
							</div>
						
						   <br>
						   <div class="input-group">
							 <?php  echo form_submit(array("name"=>"submit","value"=>"Save","class"=>"btn btn-info")); ?>
						   </div>
						</div>
					<?php echo form_close(); ?>
          </div>
				  <hr>
				  <div class="col-lg-12 col-md-12">
              <h5>Book Language List</h5>
              <div class="table-responsive" >
                  <table class="table" style="z-index:-9999">
                      <thead>
                          <tr>
                              <th>#</th>
                              <th>Name</th>
                              <th>Edit</th>
                              <th>Delete</th>
                          </tr>
                      </thead>
                      <tbody>
                       <?php 
        								
					      $i=1;
					      foreach($data as $d): ?>
      							 <tr>
      								 <td><?php echo $i++;?></td>
      								 <td><?php echo $d['name']; ?></td>
      								 <td><a href="<?php echo base_url().'bLanguageController/edit/'.$d['id']; ?>"  class='btn btn-warning'>Edit</a></td>
      								 <td><a href="<?php echo base_url().'bLanguageController/delete/'.$d['id']; ?>" class='btn btn-danger' >Delete</a></td>
      							</tr>
                       <?php endforeach; ?>    
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
          <!-- /. ROW  -->
	  
            <!-- /. ROW  --> 
        </div>
       <!-- /. PAGE INNER  -->
      </div>
   <!-- /. PAGE WRAPPER  -->
  </div>
<?php include("footer.php"); ?>
          
<?php  include("script.php"); ?>
   
</body>
</html>
