<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
include("head.php"); ?>
<body>

   <?php include("sidebar.php"); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-lg-12">
                     <h2>Book  Registration</h2>  
                     <?php 
                          if($this->session->flashdata('success')): ?>
                            <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
                        <?php endif; ?> 
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="alert alert-info">
                             <strong>Book  Registration</strong>
                        </div>
                    </div>
                    </div>
                  <!-- /. ROW  --> 
				 
                    <div class="row">
					  <form method="POST" action ="<?php echo base_url() ?>bookController/insert" > 
						  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
							   <div class="form-group">
								 <label> Name</label>
								  <input type="text" class="form-control" name='name' placeholder="" />
								  <?php echo form_error('name','<div class="text-danger" >','</div>'); ?>
							   </div>
							   
							   <div class="form-group">
								 <label> Category Name</label>
								 <select name="category_id" class="form-control">
								 <option value="">Select and option</option>
								 <?php
								  $this->load->model("bookModel");
								  $categorys = $this->bookModel->getbCategory();
								  $i=0;
								   foreach($categorys as $category){
									   echo "<option value=$category[id] >$category[name]</option>";
								   }
								 ?>
								 </select>
							   </div>
							   
							  <div class="form-group">
								 <label> Language Name</label>
								 <select name="language_id" class="form-control">
								 <option value="">Select and option</option>
								 <?php
								  $this->load->model("bookModel");
								  $languages = $this->bookModel->getbLanguage();
								  $i=0;
								   foreach($languages as $lan){
									   echo "<option value=$lan[id] >$lan[name]</option>";
								   }
								 ?>
								 </select>
							   </div>
							   
							   <div class="form-group">
								 <label> Bublisher Name</label>
								 <select name="publisher_id" class="form-control">
								 <option value="">Select and option</option>
								 <?php
								  $this->load->model("bookModel");
								  $publisher = $this->bookModel->getbPublisher();
								  $i=0;
								   foreach($publisher as $pub){
									   echo "<option value=$pub[id] >$pub[name]</option>";
								   }
								 ?>
								 </select>
							   </div>
							   
							   <div class="form-group">
								 <label> Author Name</label>
								 <select name="author_id" class="form-control">
								 <option value="">Select and option</option>
								 <?php
								  $this->load->model("bookModel");
								  $authors = $this->bookModel->getbAuthor();
								  $i=0;
								   foreach($authors as $auth){
									   echo "<option value=$auth[id] >$auth[name]</option>";
								   }
								 ?>
								 </select>
							   </div>
							    <div class="form-group">
								 <label> Number Of Pages</label>
								  <input type="number" class="form-control" name='pages' placeholder="" />

							   </div>
						
						   <br>
						   <div class="input-group">
							 <button type="submit" name="submit" class="btn btn-success" >Save</button>
						   </div>
						</div>
						</form> 
                   </div>
				  <hr>
				  
				  <div class="col-lg-12 col-md-12">
                        <h5>Book Registration</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Publisher</th>
                                        <th>Author</th>
                                        <th>Language</th>
                                        <th>Category</th>
                                        <th>Pages</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php 
								  $i=0;
								   foreach($data as $book){
									   
									   $i++;
									   $publisher_id = $book['publisher_id'];
									   $author_id    = $book['author_id'];
									   $language_id  = $book['language_id'];
									   $category_id  = $book['category_id'];
									   
									   $this->load->model('bookModel');

                                       $category= $this->bookModel->getbCategoryOne($category_id);
                                       $author= $this->bookModel->getbAuthorOne($author_id);
                                       $language =  $this->bookModel->getbLanguageOne($language_id);
                                       $publisher = $this->bookModel->getbPublisherOne($publisher_id);
									   
									   echo "<tr>
									             <td>$i</td>
									             <td>$book[name]</td>
									             <td>$publisehr[name]</td>
									             <td>$author[name]</td>
									             <td>$language[name]</td>
									             <td>$category[name]</td>
									             <td>$book[pages]</td>
									         </tr>";
								     }
								 ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- /. ROW  -->
				  
                  <!-- /. ROW  --> 
              </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
      <?php //include("footer.php"); ?>
          
<?php  include("script.php"); ?>
   
</body>
</html>
