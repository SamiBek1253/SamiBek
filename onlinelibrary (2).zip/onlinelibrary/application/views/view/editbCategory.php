<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
include("head.php"); ?>
<body>
     
   <?php include("sidebar.php"); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-lg-12">
                     <h2><?php echo $title;?></h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="alert alert-info">
                             <strong><?php echo $title;?> </strong>
                        </div>
					            	<?php 
                          if($this->session->flashdata('success')): ?>
                            <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
                        <?php endif; ?>
                    </div>
                    </div>
                  <!-- /. ROW  --> 
				 
                    <div class="row">
					     <form method="POST" action="<?php echo base_url().'bCategoryController/updateCol/'.$data[id];?>" >
						  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
							   <div class="form-group">
								 <label><?php echo form_label("Category Name","name"); ?></label>
                  <?php echo form_input(array('name'=>'name','id'=>'name','Placeholder'=>"name",'autocomplete'=>'off','value'=>$data['name'],'class'=>'form-control')); ?>
                  <?php echo form_error('name','<div class="text-danger" >','</div>'); ?>
							</div>
						   <br>
						   <div class="input-group">
							 <?php  echo form_submit(array("name"=>"submit","value"=>"Update","class"=>"btn btn-warning")); ?>
						   </div>
						</div>
					<?php echo form_close(); ?>
          </div>
            </div>
          <!-- /. ROW  -->
	  
            <!-- /. ROW  --> 
        </div>
       <!-- /. PAGE INNER  -->
      </div>
   <!-- /. PAGE WRAPPER  -->
  </div>
<?php include("footer.php"); ?>
          
<?php  include("script.php"); ?>
   
</body>
</html>
