<div class="footer"  style="margin-bottom:-100px !important; z-index:-9999 !important">    
	<div class="row">
		<div class="col-lg-12" >
			&copy;  <?php echo Date("Y"); ?> | Design by: <a href="https://www.cs.com" style="color:#fff;" target="_blank">CS Students</a>
		</div>
	</div>
</div>