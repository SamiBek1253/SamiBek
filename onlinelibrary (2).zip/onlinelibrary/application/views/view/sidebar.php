       
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="<?php echo base_url() ?>assets/img/logo.png" />
                    </a>
                </div>
                <span class="logout-spn" >
                  <a href="uController/logout" style="color:#fff;">LOGOUT</a>  
                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="active-link">
                        <a href="<?php echo base_url() ?>homeController" ><i class="fa fa-desktop "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url() ?>bCategoryController/"><i class="fa fa-table "></i> Category Registratioin</a>
                    </li>
                    
                     <li>
                        <a href="<?php echo base_url() ?>bPublisherController"><i class="fa fa-edit "></i>Publisher Registratioin</a>
                    </li>

                    <li>
                        <a href="<?php echo base_url() ?>bAuthorController"><i class="fa fa-qrcode "></i>Author Registratioin</a>
                    </li>
                    
                    <li>
                        <a href="<?php echo base_url() ?>bLanguageController"><i class="fa fa-bar-chart-o"></i>Language Registratioin</a>
                    </li>
                    
                    <li>
                        <a href="<?php echo base_url() ?>bookController"><i class="fa fa-table "></i>Book Registratioin</a>
                    </li>
                    
                    
                    <li>
                        <a href="<?php echo base_url() ?>uCategoryController"><i class="fa fa-edit "></i>User Category Registratioin</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url() ?>uController"><i class="fa fa-table "></i>User Registratioin</a>
                    </li>
                    
                </ul>
               </div>

        </nav>